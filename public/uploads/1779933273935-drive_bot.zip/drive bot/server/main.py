from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import base64
import os
import json
import uuid
from datetime import datetime
from pathlib import Path

app = FastAPI(title="Vault Storage API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

STORAGE_DIR = Path("../storage")
STORAGE_DIR.mkdir(exist_ok=True)
META_FILE = STORAGE_DIR / "metadata.json"


def load_meta():
    if META_FILE.exists():
        with open(META_FILE, "r") as f:
            return json.load(f)
    return {}


def save_meta(meta):
    with open(META_FILE, "w") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)


@app.get("/files")
def list_files():
    meta = load_meta()
    return list(meta.values())


@app.post("/upload")
async def upload_file(file: UploadFile = File(...), source: str = "web"):
    content = await file.read()
    encoded = base64.b64encode(content).decode("utf-8")

    file_id = str(uuid.uuid4())[:8]
    ext = Path(file.filename).suffix
    stored_name = f"{file_id}{ext}.b64"

    filepath = STORAGE_DIR / stored_name
    with open(filepath, "w") as f:
        f.write(encoded)

    meta = load_meta()
    meta[file_id] = {
        "id": file_id,
        "name": file.filename,
        "stored_name": stored_name,
        "size": len(content),
        "source": source,
        "uploaded_at": datetime.now().isoformat(),
        "content_type": file.content_type or "application/octet-stream",
    }
    save_meta(meta)

    return {"id": file_id, "name": file.filename, "message": "تم الرفع بنجاح"}


@app.get("/download/{file_id}")
def download_file(file_id: str):
    meta = load_meta()
    if file_id not in meta:
        raise HTTPException(status_code=404, detail="الملف غير موجود")

    info = meta[file_id]
    filepath = STORAGE_DIR / info["stored_name"]

    with open(filepath, "r") as f:
        encoded = f.read()

    decoded = base64.b64decode(encoded)
    import base64 as b64_module
    return JSONResponse({
        "name": info["name"],
        "content_type": info["content_type"],
        "data": encoded  # raw base64 so client can download
    })


@app.delete("/delete/{file_id}")
def delete_file(file_id: str):
    meta = load_meta()
    if file_id not in meta:
        raise HTTPException(status_code=404, detail="الملف غير موجود")

    info = meta[file_id]
    filepath = STORAGE_DIR / info["stored_name"]
    if filepath.exists():
        filepath.unlink()

    del meta[file_id]
    save_meta(meta)

    return {"message": "تم الحذف"}


@app.get("/stats")
def get_stats():
    meta = load_meta()
    total_size = sum(f["size"] for f in meta.values())
    return {
        "total_files": len(meta),
        "total_size": total_size,
    }
