import discord
from discord.ext import commands
import aiohttp
import os
from dotenv import load_dotenv

load_dotenv()

TOKEN = os.getenv("DISCORD_TOKEN")
API_URL = os.getenv("API_URL", "http://localhost:8000")
ALLOWED_CHANNEL_ID = int(os.getenv("CHANNEL_ID", "0"))  # قناة محددة للبوت

intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(command_prefix="!", intents=intents)


@bot.event
async def on_ready():
    print(f"✅ البوت شغال: {bot.user}")


@bot.event
async def on_message(message):
    if message.author.bot:
        return

    # فقط في القناة المحددة (اختياري)
    if ALLOWED_CHANNEL_ID and message.channel.id != ALLOWED_CHANNEL_ID:
        return

    if message.attachments:
        for attachment in message.attachments:
            await message.channel.send(f"📦 جاري رفع `{attachment.filename}`...")
            try:
                async with aiohttp.ClientSession() as session:
                    # تحميل الملف من ديسكورد
                    async with session.get(attachment.url) as resp:
                        file_data = await resp.read()

                    # رفعه للسيرفر
                    form = aiohttp.FormData()
                    form.add_field(
                        "file",
                        file_data,
                        filename=attachment.filename,
                        content_type=attachment.content_type or "application/octet-stream"
                    )
                    form.add_field("source", "discord")

                    async with session.post(f"{API_URL}/upload", data=form) as upload_resp:
                        result = await upload_resp.json()

                embed = discord.Embed(
                    title="✅ تم الحفظ بنجاح!",
                    color=0x5865F2
                )
                embed.add_field(name="الملف", value=attachment.filename, inline=True)
                embed.add_field(name="الحجم", value=f"{attachment.size:,} bytes", inline=True)
                embed.add_field(name="ID", value=result.get("id", "?"), inline=True)
                embed.set_footer(text="مشفر بـ Base64 ومحفوظ في السيرفر")
                await message.channel.send(embed=embed)

            except Exception as e:
                await message.channel.send(f"❌ خطأ أثناء الرفع: `{e}`")

    await bot.process_commands(message)


@bot.command(name="ملفات", aliases=["files", "list"])
async def list_files(ctx):
    """عرض قائمة الملفات المحفوظة"""
    async with aiohttp.ClientSession() as session:
        async with session.get(f"{API_URL}/files") as resp:
            files = await resp.json()

    if not files:
        await ctx.send("📭 لا توجد ملفات محفوظة.")
        return

    embed = discord.Embed(title=f"📁 الملفات المحفوظة ({len(files)})", color=0x5865F2)
    for f in files[:10]:
        size_kb = f["size"] / 1024
        embed.add_field(
            name=f['name'][:50],
            value=f"`ID: {f['id']}` | {size_kb:.1f} KB | من {f['source']}",
            inline=False
        )
    if len(files) > 10:
        embed.set_footer(text=f"وعندك {len(files)-10} ملف إضافي — شوفهم بالويب")
    await ctx.send(embed=embed)


@bot.command(name="احصائيات", aliases=["stats"])
async def stats(ctx):
    """إحصائيات التخزين"""
    async with aiohttp.ClientSession() as session:
        async with session.get(f"{API_URL}/stats") as resp:
            data = await resp.json()

    embed = discord.Embed(title="📊 إحصائيات الفولت", color=0x57F287)
    embed.add_field(name="عدد الملفات", value=data["total_files"], inline=True)
    embed.add_field(name="إجمالي الحجم", value=f"{data['total_size']/1024:.1f} KB", inline=True)
    await ctx.send(embed=embed)


@bot.command(name="حذف", aliases=["delete"])
async def delete_file(ctx, file_id: str):
    """حذف ملف بالـ ID"""
    async with aiohttp.ClientSession() as session:
        async with session.delete(f"{API_URL}/delete/{file_id}") as resp:
            if resp.status == 200:
                await ctx.send(f"🗑️ تم حذف الملف `{file_id}` بنجاح.")
            else:
                await ctx.send(f"❌ ما لقيت الملف بالـ ID هذا.")


bot.run(TOKEN)
